'''
package using pycairo to allow better bitmap rendering
'''
__version__ = '0.4.0'
__all__ = (
        'GState',
        'pil2pict',
        )
from . gstate import *
from . pil2pict import pil2pict
